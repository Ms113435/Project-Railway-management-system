package RailwayManagementSystem;

import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;

import javax.swing.JOptionPane;
import java.io.File;
import java.io.IOException;

public class TicketGenerator {

    private String passengerName;
    private String passengerID;
    private String passengerTel;
    private String passengerEmail;
    private String passengerNID;
    private String tripDetails;
    private int numOfTickets;
    private double totalPrice;

    public TicketGenerator(String passengerName, String passengerID, String passengerTel, String passengerEmail, 
                        String passengerNID, String tripDetails, int numOfTickets, double totalPrice) {
        this.passengerName = passengerName;
        this.passengerID = passengerID;
        this.passengerTel = passengerTel;
        this.passengerEmail = passengerEmail;
        this.passengerNID = passengerNID;
        this.tripDetails = tripDetails;
        this.numOfTickets = numOfTickets;
        this.totalPrice = totalPrice;
    }

    public void generateTicket() {
        String filePath = "G:\\Java\\TestProject\\RailwayManagementSystem\\Tickets\\ticket_" + passengerID + ".pdf";
        try {
            PdfWriter writer = new PdfWriter(new File(filePath));
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            // Adding ticket details
            document.add(new Paragraph("CIET Railway"));
            document.add(new Paragraph("Passenger Info:"));
            document.add(new Paragraph("Passenger Name: " + passengerName));
            document.add(new Paragraph("Passenger ID: " + passengerID));
            document.add(new Paragraph("Phone: " + passengerTel));
            document.add(new Paragraph("Email: " + passengerEmail));
            document.add(new Paragraph("NID: " + passengerNID));
            document.add(new Paragraph("Trip Details: " + tripDetails));
            document.add(new Paragraph("Number of Tickets: " + numOfTickets));
            document.add(new Paragraph("Total Price: $" + totalPrice));

            document.close();
            JOptionPane.showMessageDialog(null, "Ticket generated successfully: " + filePath);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error generating ticket: " + e.getMessage());
        }
    }
}
