package RailwayManagementSystem;

import java.util.ArrayList;
import java.sql.SQLException;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import Trips.BookTrip;
import Trips.Trip;
import Trips.TripsDatabase;

public class Main {
    private static JFrame frame;
    private static JPanel table;
    private static GridLayout gridLayout;
    private static Database database;

    public static void main(String[] args) {
        // Show the login window
        new LoginWindow();
        // The main interface will be shown upon successful login
    }

    public static void showMainInterface() throws SQLException {
        database = new Database();

        frame = new JFrame("Railway Management System");
        frame.setSize(1455, 650);
        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().setBackground(Color.decode("#EBFFD8"));
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout(20, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 40, 30, 40));
        panel.setBackground(Color.decode("#d2f0b6"));

        JLabel title = new JLabel("Welcome");
        title.setForeground(Color.decode("#012030"));
        title.setFont(new Font(null, Font.BOLD, 35));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(title, BorderLayout.NORTH);

        gridLayout = new GridLayout(6, 1);
        table = new JPanel(gridLayout);
        table.setBackground(Color.decode("#EBFFD8"));

        ArrayList<Trip> trips = TripsDatabase.getAllTrips(database);
        refreshTable(trips);

        JButton modify = new JButton("Modify");
        modify.setBackground(Color.decode("#45c4b0"));
        modify.setForeground(Color.white);
        modify.setFont(new Font(null, Font.BOLD, 22));
        modify.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ModifyList(frame, database);
            }
        });
        panel.add(modify, BorderLayout.SOUTH);

        JScrollPane sp = new JScrollPane(table);
        panel.add(sp, BorderLayout.CENTER);

        frame.add(panel, BorderLayout.CENTER);

        frame.setVisible(true);
    }

    public static void refreshTable(ArrayList<Trip> trips) {
        table.removeAll();
        table.repaint();
        table.revalidate();
        int rows = trips.size() + 1;
        if (rows < 6)
            rows = 6;
        gridLayout.setRows(rows);
        table.add(row(0, null));
        for (int i = 0; i < trips.size(); i++) {
            JPanel trip = row(i + 1, trips.get(i));
            table.add(trip);
        }
    }

    private static JPanel row(int index, Trip trip) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 15));
        boolean isHeader = (trip == null); 
        if (isHeader) { row.setBackground(Color.decode("#A9CCE3")); // Set a different background color for the header row 
        } else { 
            if (index % 2 == 0) 
            row.setBackground(Color.decode("#e5e5e5")); 
            else 
            row.setBackground(Color.decode("#EEEEEE")); }
        String trainS, startS, destS, dateS, deptS, arrS, priceS, statusS;
        if (isHeader) {
            trainS = "Train";
            startS = "From";
            destS = "To";
            dateS = "Date";
            deptS = "Departure Time";
            arrS = "Arrival Time";
            priceS = "Price";
            statusS = "Seats";
        } else {
            trainS = trip.getTrain().getTrainName();
            startS = trip.getStart();
            destS = trip.getDestination();
            dateS = trip.getDate();
            deptS = trip.getDepartureTime();
            arrS = trip.getArrivalTime();
            priceS = String.format("%.2f BDT", trip.getPrice());
            int availableSeats = trip.getTrain().getCapacity() - trip.getBookedSeats();
            statusS = availableSeats > 0 ? availableSeats + " seats available" : "Booked";
        }
        JLabel train = JLabel(trainS, isHeader ? 125 : 125);
        if (isHeader) {
            train.setFont(new Font(null, Font.BOLD, 24));
        }
        row.add(train);
        JLabel start = JLabel(startS, isHeader ? 125 : 125);
        if (isHeader) {
            start.setFont(new Font(null, Font.BOLD, 24));
        }
        row.add(start);
        JLabel dest = JLabel(destS, isHeader ? 125 : 125);
        if (isHeader) {
            dest.setFont(new Font(null, Font.BOLD, 24));
        }
        row.add(dest);
        JLabel date = JLabel(dateS, isHeader ? 125 : 125);
        if (isHeader) {
            date.setFont(new Font(null, Font.BOLD, 24));
        }
        row.add(date);
        JLabel depTime = JLabel(deptS, isHeader ? 150 : 150);
        if (isHeader) {
            depTime.setFont(new Font(null, Font.BOLD, 24));
        }
        row.add(depTime);
        JLabel arrTime = JLabel(arrS, isHeader ? 150 : 150);
        if (isHeader) {
            arrTime.setFont(new Font(null, Font.BOLD, 24));
        }
        row.add(arrTime);
        JLabel price = JLabel(priceS, isHeader ? 120 : 120);
        if (isHeader) {
            price.setFont(new Font(null, Font.BOLD, 24));
        }
        row.add(price);
        JLabel status = JLabel(statusS, isHeader ? 150 : 150);
        if (isHeader) {
            status.setFont(new Font(null, Font.BOLD, 24));
        }
        row.add(status);
        if (!isHeader) {
            row.setCursor(new Cursor(Cursor.HAND_CURSOR));
            row.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    try {
                        new BookTrip(frame, database, trip);
                    } catch (SQLException e1) {
                        JOptionPane.showMessageDialog(frame, e1.getMessage());
                    }
                }
                @Override
                public void mousePressed(MouseEvent e) {}

                @Override
                public void mouseReleased(MouseEvent e) {}

                @Override
                public void mouseEntered(MouseEvent e) {}

                @Override
                public void mouseExited(MouseEvent e) {}
            });
        }
        return row;
    }

    private static JLabel JLabel(String text, int width){
        JLabel label = new JLabel(text);
        label.setPreferredSize(new Dimension(width, 30));
        label.setFont(new Font(null, Font.PLAIN, 20));
        label.setForeground(Color.decode("#13678A"));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        return label;
    }
}