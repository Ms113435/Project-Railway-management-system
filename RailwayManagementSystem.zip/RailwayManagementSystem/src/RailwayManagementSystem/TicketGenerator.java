package RailwayManagementSystem;

import Trips.Trip;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;
import java.io.File;
import java.io.IOException;

public class TicketGenerator {

    private String passengerName;
    private String passengerID;
    private String passengerTel;
    private String passengerEmail;
    private String passengerNID;
    private Trip trip; 
    private int numOfTickets;
    private double totalPrice;

    public TicketGenerator(String passengerName, String passengerID, String passengerTel, String passengerEmail, 
                        String passengerNID, Trip trip, int numOfTickets, double totalPrice) {
        this.passengerName = passengerName;
        this.passengerID = passengerID;
        this.passengerTel = passengerTel;
        this.passengerEmail = passengerEmail;
        this.passengerNID = passengerNID;
        this.trip = trip;
        this.numOfTickets = numOfTickets;
        this.totalPrice = totalPrice;
    }

    public void generateTicket() {
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String filePath = "F:\\Project RMS\\Tickets\\ticket_" + passengerID + "_" + timeStamp + ".pdf";
        try {
            PdfWriter writer = new PdfWriter(new File(filePath));
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf, PageSize.A5);
            document.setMargins(36, 36, 36, 36);
            // Create a table 
            Table table = new Table(1);
            table.setHorizontalAlignment(com.itextpdf.layout.properties.HorizontalAlignment.CENTER); // Center the table
            // Adding ticket details to the table
            table.addCell(new Cell().add(new Paragraph("CIET Railway").setBold().setFontSize(20)).setTextAlignment(com.itextpdf.layout.properties.TextAlignment.CENTER));
            table.addCell(new Cell().add(new Paragraph("Passenger Info:").setBold().setFontSize(16)).setTextAlignment(com.itextpdf.layout.properties.TextAlignment.CENTER));
    
            table.addCell(new Cell().add(new Paragraph("Passenger Name: " + passengerName)));
            table.addCell(new Cell().add(new Paragraph("Passenger ID: " + passengerID)));
            table.addCell(new Cell().add(new Paragraph("Phone: " + passengerTel)));
            table.addCell(new Cell().add(new Paragraph("Email: " + passengerEmail)));
            table.addCell(new Cell().add(new Paragraph("NID: " + passengerNID)));

            table.addCell(new Cell().add(new Paragraph("Trip Info:").setBold().setFontSize(16)).setTextAlignment(com.itextpdf.layout.properties.TextAlignment.CENTER));

            // Adding trip details
            table.addCell(new Cell().add(new Paragraph("Start From: " + trip.getStart())));
            table.addCell(new Cell().add(new Paragraph("Destination To: " + trip.getDestination())));
            table.addCell(new Cell().add(new Paragraph("Departure Time: " + trip.getDepartureTime())));
            table.addCell(new Cell().add(new Paragraph("Arrival Time: " + trip.getArrivalTime())));
            table.addCell(new Cell().add(new Paragraph("Date: " + trip.getDate())));
            table.addCell(new Cell().add(new Paragraph("Train: " + trip.getTrain().getTrainName()))); 

            table.addCell(new Cell().add(new Paragraph("Number of Tickets: " + numOfTickets)));
            table.addCell(new Cell().add(new Paragraph("Total Price: BDT " + String.format("%.0f", totalPrice))));

    
            // Add the table to the document
            document.add(table);
    
            document.close();
            JOptionPane.showMessageDialog(null, "Ticket generated successfully for Passenger : " + passengerID);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error generating ticket: " + e.getMessage());
        }
    }
}
