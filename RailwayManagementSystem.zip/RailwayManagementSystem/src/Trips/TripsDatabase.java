package Trips;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Employees.Employee;
import Employees.EmployeesDatabase;
import RailwayManagementSystem.Database;
import Trains.Train;
import Trains.TrainsDatabase;


public class TripsDatabase {

    public static void AddTrip(Trip t , Database database) throws SQLException{
        String insert = "INSERT INTO `railway management system`.`trips`"+
                        "(`ID`,`Start`,`Destination`,`DepartureTime`,`ArrTime`,`Date`,`BookedSeats`,`Price`,`Driver`,`Train`)"+
                        "VALUES('"+t.getID()+"','"+t.getStart()+"','"+t.getDestination()+"','"+t.getDepartureTime()+"','"
                        +t.getArrivalTime()+"','"+t.getDate()+"','"+t.getBookedSeats()+"','"+t.getPrice()+"','"+t.getDriver().getID()+"','"+t.getTrain().getID()+"');";
        database.getStatement().execute(insert);

        String create = "CREATE TABLE `Trip "+t.getID()+" Passengers`(Passenger int, Tickets int);";
        database.getStatement().execute(create);

    }

    public static int getNextID(Database database) throws SQLException{
        int id = 0;
        ArrayList<Trip> trips = getAllTrips(database);
        int size = trips.size();
        if(size != 0)id = trips.get(size - 1).getID() + 1;
        return id;
    }

    public static ArrayList<Trip> getAllTrips(Database database) throws SQLException {
        ArrayList<Trip> trips = new ArrayList<>();
        ArrayList<Integer> drivers = new ArrayList<>();
        ArrayList<Integer> trains = new ArrayList<>();
        String select = "SELECT * FROM `trips`;";
        ResultSet rs = database.getStatement().executeQuery(select);
        while (rs.next()) {
            Trip t = new Trip();
            t.setID(rs.getInt("ID"));
            t.setStart(rs.getString("Start"));
            t.setDestination(rs.getString("Destination"));
            t.setDepartureTime(rs.getString("DepartureTime"));
            t.setArrivalTime(rs.getString("ArrTime"));
            t.setDate(rs.getString("Date"));
            t.setBookedSeats(rs.getInt("BookedSeats"));
            t.setPrice(rs.getDouble("Price"));
            drivers.add(rs.getInt("Driver"));
            trains.add(rs.getInt("Train"));
            trips.add(t);
        }
        for (int i = 0; i < trips.size(); i++) {
            Employee driver = EmployeesDatabase.getEmployee(String.valueOf(drivers.get(i)), database);
            Train train = TrainsDatabase.getTrain(String.valueOf(trains.get(i)), database);
            if (driver == null) {
                driver = new Employee();
                driver.setID(-1);
                driver.setName("Unknown Driver");
                driver.setEmail("Unknown");
                driver.setTel("Unknown");
                driver.setSalary(0.0);
                driver.setPosition("Unknown");
            }
            if (train == null) {
                train = new Train();
                train.setID(-1);
                train.setCapacity(0);
                train.setTrainName("Unknown Train");
            }
            trips.get(i).setDriver(driver);
            trips.get(i).setTrain(train);
        }
        return trips;
    }
    

    public static String[] getIDs(Database database) throws SQLException{
        ArrayList<Trip> trips = getAllTrips(database);
        String[]  array = new String[trips.size()];
        for(int i = 0; i < trips.size(); i++){
            array[i]  = String.valueOf(trips.get(i).getID());
        }
        return array;
    }

    public static Trip getTrip(String id, Database database) throws SQLException{

        String select = "SELECT `ID`,`Start`,`Destination`,`DepartureTime`,`ArrTime`,`Date`,`BookedSeats`,`Price`,`Driver`,`Train`FROM `trips` WHERE `ID` = "+id+";";
        ResultSet rs = database.getStatement().executeQuery(select);
        rs.next();
        Trip t = new Trip();
            t.setID(rs.getInt("ID"));
            t.setStart(rs.getString("Start"));
            t.setDestination(rs.getString("Destination"));
            t.setDepartureTime(rs.getString("DepartureTime"));
            t.setArrivalTime(rs.getString("ArrTime"));
            t.setDate(rs.getString("Date"));
            t.setBookedSeats(rs.getInt("BookedSeats"));
            t.setPrice(rs.getDouble("Price"));
            int driverID = rs.getInt("Driver");
            int trainID = rs.getInt("Train");
            t.setDriver(EmployeesDatabase.getEmployee(String.valueOf(driverID), database));
            t.setTrain(TrainsDatabase.getTrain(String.valueOf(trainID), database));
            return t;
    }

    public static void EditTrip(Trip t, Database database) throws SQLException{
        String update = "UPDATE `railway management system`.`trips` SET `Start` ='"+t.getStart()+"',`Destination` ='"+t.getDestination()+"',`DepartureTime` ='"+t.getDepartureTime()+"',`ArrTime` ='"+t.getArrivalTime()+"',"
        +"`Date` ='"+t.getDate()+"',`Price` ='"+t.getPrice()+"',`Driver` ='"+t.getDriver().getID()+"',`Train` ='"+t.getTrain().getID()+"' WHERE `ID` ="+t.getID()+" ;";
        database.getStatement().execute(update);
    }

    public static void DeleteTrip(String id, Database database) throws SQLException{
        String delete = "DELETE FROM `trips` WHERE `ID` ="+id+";";
        database.getStatement().execute(delete);

        String drop = "DROP TABLE `Trip "+id+" Passengers`;";
        database.getStatement().execute(drop);
    }

    public static void BookTrip(Trip t, String passengerID, String numTickets, Database d) throws SQLException {
        try {
            // Insert passenger ticket info into the database
            String insert = "INSERT INTO `trip " + t.getID() + " passengers` (`Passenger`, `Tickets`) VALUES ('" + passengerID + "', '" + numTickets + "')";
            d.getStatement().execute(insert);
        
            // Update the booked seats in the trips table
            t.setBookedSeats(t.getBookedSeats() + Integer.parseInt(numTickets));
            String update = "UPDATE `trips` SET `BookedSeats` = '" + t.getBookedSeats() + "' WHERE `ID` = " + t.getID() + ";";
            d.getStatement().execute(update);
        } catch (SQLException e) {
            //print the error message 
            System.err.println("SQLException: " + e.getMessage());
            throw e;  // Rethrow the exception to be handled by the calling method
        }
    }    
    
    public static String[][] getPassengers(String id, Database database) throws SQLException{
        String select = "SELECT * FROM `trip "+id+" passengers` ;";
        ResultSet rs = database.getStatement().executeQuery(select);
        ArrayList<Integer> ids = new ArrayList<>();
        ArrayList<Integer> nums = new ArrayList<>();
        while (rs.next()) {
            ids.add(rs.getInt("Passenger"));
            nums.add(rs.getInt("Tickets"));
        }
        String[][] array = new String[ids.size()][2];
        for(int i = 0; i < ids.size(); i++){
            array[i][0] = String.valueOf(ids.get(i));
            array[i][1] = String.valueOf(nums.get(i));
        }
        return array;
    }

}
