package Trips;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import Passengers.PassengersDatabase;
import Passengers.Passenger;
import RailwayManagementSystem.Database;
import RailwayManagementSystem.GUI;
import RailwayManagementSystem.Main;
import RailwayManagementSystem.TicketGenerator;

public class BookTrip {

    JComboBox<String> passenger;
    JLabel id , name, tel, email, nid;

    public BookTrip(JFrame parent, Database database, Trip trip) throws SQLException{
        JFrame frame = new JFrame("Book Trip");
        frame.setSize(750, 675);
        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().setBackground(GUI.background);
        frame.setLocationRelativeTo(parent);

        JPanel panel = new JPanel(new GridLayout(10, 2, 20, 20));
        panel.setBackground(null);
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 30, 50));
        panel.add(GUI.JLabel("Passenger:"));
        passenger = GUI.JComboBox(PassengersDatabase.getPassengersNames(database));
        panel.add(passenger);

        panel.add(GUI.JLabel("ID:"));
        id = GUI.JLabel("");
        panel.add(id);

        panel.add(GUI.JLabel("Name:"));
        name = GUI.JLabel("");
        panel.add(name);

        panel.add(GUI.JLabel("Tel:"));
        tel = GUI.JLabel("");
        panel.add(tel);

        panel.add(GUI.JLabel("Email:"));
        email = GUI.JLabel("");
        panel.add(email);

        panel.add(GUI.JLabel("NID:"));
        nid = GUI.JLabel("");
        panel.add(nid);

        panel.add(GUI.JLabel("Number of tickets:"));
        JTextField numOfTickets = GUI.JTextField();
        panel.add(numOfTickets);

        panel.add(GUI.JLabel("Price"));
        JLabel price = GUI.JLabel(String.format("%.2f BDT", trip.getPrice()));
        panel.add(price);

        panel.add(GUI.JLabel("Total:"));
        JLabel total = GUI.JLabel("");
        panel.add(total);

        JButton cancel = GUI.JButton("Cancel");
        cancel.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
            
        });
        panel.add(cancel);

        JButton submit = GUI.JButton("Submit");
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int numTickets = Integer.parseInt(numOfTickets.getText());
                    
                    // Get available seats for the trip
                    int availableSeats = trip.getAvailableSeats();
                    
                    // Validate number of tickets
                    if (numTickets <= 0) {
                        JOptionPane.showMessageDialog(frame, "Number of tickets must be positive.");
                        return;
                    } else if (numTickets > 4) {
                        JOptionPane.showMessageDialog(frame, "You can only book up to 4 tickets at a time.");
                        return;
                    } else if (numTickets > availableSeats) {
                        JOptionPane.showMessageDialog(frame, "Not enough available seats.");
                        return;
                    }
        
                    // Proceed with booking
                    TripsDatabase.BookTrip(trip, id.getText(), numOfTickets.getText(), database);
                    JOptionPane.showMessageDialog(frame, "Booked successfully");
        
                    // Generate ticket
                    TicketGenerator ticketGenerator = new TicketGenerator(
                        name.getText(),
                        id.getText(),
                        tel.getText(),
                        email.getText(),
                        nid.getText(),
                        trip,
                        numTickets,
                        Double.parseDouble(total.getText().replace(" BDT", ""))  // Parse price to total
                    );
                    ticketGenerator.generateTicket();
        
                    // Refresh trips table
                    Main.refreshTable(TripsDatabase.getAllTrips(database));
                    frame.dispose();
        
                } catch (SQLException e1) {
                    JOptionPane.showMessageDialog(frame, "Operation Failed");
                    frame.dispose();
                } catch (NumberFormatException e2) {
                    JOptionPane.showMessageDialog(frame, "Invalid number of tickets.");
                } catch (IllegalArgumentException e3) {
                    JOptionPane.showMessageDialog(frame, e3.getMessage());
                }
            }
        });
        panel.add(submit);

        if(passenger.getSelectedItem()!= null) refreshPassengerData(database);

        passenger.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    refreshPassengerData(database);
                } catch (SQLException e1) {
                    JOptionPane.showMessageDialog(frame, e1.getMessage());
                    frame.dispose();
                }
            }
        });
        
        numOfTickets.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateTotalAmount(numOfTickets, trip, total);
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                updateTotalAmount(numOfTickets, trip, total);
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
                updateTotalAmount(numOfTickets, trip, total);
            }
        });

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);

    }

    private void refreshPassengerData(Database database) throws SQLException{
        String Passenger = passenger.getSelectedItem().toString();
        Passenger p = PassengersDatabase.getPassengerByName(Passenger, database);
        id.setText(String.valueOf(p.getID()));
        name.setText(String.valueOf(p.getName()));
        tel.setText(String.valueOf(p.getTel()));
        email.setText(String.valueOf(p.getEmail()));
        nid.setText(String.valueOf(p.getNID()));
    }

    private void updateTotalAmount(JTextField numOfTickets, Trip trip, JLabel total) {
        try {
            int num = Integer.parseInt(numOfTickets.getText());
            double price = trip.getPrice();
            double totalAmount = num * price;
            total.setText(String.format("%.2f BDT", totalAmount));
        } catch (NumberFormatException e) {
            total.setText("");
        }
    }

}
