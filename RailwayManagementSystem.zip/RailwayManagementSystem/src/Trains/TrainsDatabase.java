package Trains;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import RailwayManagementSystem.Database;

public class TrainsDatabase {



    public static void AddTrain(Train t, Database database) throws SQLException{
        String insert = "insert into `trains`(`ID`, `Capacity`, `Description`)values"+"('"+t.getID()+"', '"+t.getCapacity()+"','"+t.getTrainName()+"');";
        database.getStatement().execute(insert);

    }
    public static int getNextID(Database database) throws SQLException{
        int id = 0; 
        if(getAllTrains(database).size()!= 0){
            id = getAllTrains(database).get(getAllTrains(database).size()-1).getID() + 1;
        }
        return id;
    }

    public static ArrayList<Train>getAllTrains(Database database) throws SQLException{
        String select = "select * from `trains`;";
        ArrayList<Train>trains = new ArrayList<>();
        ResultSet rs = database.getStatement().executeQuery(select);
        while(rs.next()){
            Train t = new Train();
            t.setID(rs.getInt("ID"));
            t.setCapacity(rs.getInt("Capacity"));
            t.setTrainName(rs.getString("Description"));
            trains.add(t);
        }
        return trains;
    }

    public static String[] getTrainsIDs(Database database) throws SQLException{
        ArrayList<Train> trains = getAllTrains(database);
        String[] array = new String[trains.size()];
        for(int i = 0; i < trains.size(); i++){
            array[i] = String.valueOf(trains.get(i).getID());
        }
        return array;
    }

    public static Train getTrain(String id, Database database) throws SQLException {
        Train t = new Train();
        String select = "SELECT `ID`, `Capacity`, `Description` FROM `railway management system`.`trains` WHERE `ID` = " + id + ";";
        ResultSet rs = database.getStatement().executeQuery(select);
        if (rs.next()) {
            t.setID(rs.getInt("ID"));
            t.setCapacity(rs.getInt("Capacity"));
            t.setTrainName(rs.getString("Description"));
        } else {
            // Return a default Train object with placeholder values
            t.setID(-1);
            t.setCapacity(0);
            t.setTrainName("Unknown Train");
        }
        return t;
    }
    

    public static void EditTrain(Train t, Database database) throws SQLException{
        String update = "UPDATE `railway management system`.`trains` SET `Capacity` = '"+t.getCapacity()+
                    "', `Description` = '"+t.getTrainName()+"' WHERE `ID` = "+t.getID()+";";
        database.getStatement().execute(update);
        
    }

    public static void DeleteTrain(String id, Database database) throws SQLException{
        String delete = "DELETE FROM `railway management system`.`trains` WHERE `ID` = "+id+";";
        database.getStatement().execute(delete);


    }

    public static String[] getTrains(Database database) throws SQLException{
        ArrayList<Train> trains = getAllTrains(database);
        String[] array = new String[trains.size()];
        for(int i = 0; i < trains.size(); i++){
            array[i] = trains.get(i).getTrainName();
        }
        return array;
    }

    public static Train getTrainByDescription(String description, Database database) throws SQLException{
        Train t = new Train();
        String select = "select `ID`, `Capacity`, `Description` from `railway management system`.`trains` where `Description` = '"+description+"';";
        ResultSet rs = database.getStatement().executeQuery(select);
        rs.next();
        t.setID(rs.getInt("ID"));
        t.setCapacity(rs.getInt("Capacity"));
        t.setTrainName(rs.getString("Description"));
        return t;
    }

}
