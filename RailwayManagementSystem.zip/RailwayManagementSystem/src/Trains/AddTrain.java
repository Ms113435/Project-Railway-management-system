package Trains;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;

import RailwayManagementSystem.Database;
import RailwayManagementSystem.GUI;

public class AddTrain {

    public AddTrain(JFrame oldFrame, Database database) throws SQLException{

        JFrame frame = new JFrame("Add Train");
        frame.setSize(750, 400);
        frame.getContentPane().setLayout(new BorderLayout());
        frame.setLocationRelativeTo(oldFrame);
        frame.getContentPane().setBackground(Color.decode("#ebffd8"));

        JPanel panel = new JPanel(new GridLayout(4, 2, 20, 20));
        panel.setBackground(null);
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 30, 50));

        panel.add(GUI.JLabel("ID:"));
        JLabel id = GUI.JLabel(String.valueOf(TrainsDatabase.getNextID(database)));
        panel.add(id);

        panel.add(GUI.JLabel("Capacity:"));
        JTextField capacity = new JTextField();
        panel.add(capacity);

        panel.add(GUI.JLabel("Train Name:"));
        JTextField trainName = GUI.JTextField();
        panel.add(trainName);

        JButton cancel = GUI.JButton("Cancel");
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        panel.add(cancel);

        JButton submit = GUI.JButton("Submit");
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get the capacity value and validate it
                    int trainCapacity = Integer.parseInt(capacity.getText());
                    // Check if the capacity is a positive number
                    if (trainCapacity <= 0) {
                        JOptionPane.showMessageDialog(frame, "Capacity must be a positive number.");
                        return;
                    }

                    // Create a new train and set the values
                    Train t = new Train();
                    t.setID(Integer.parseInt(id.getText()));  // The ID is auto-generated from the database
                    t.setCapacity(trainCapacity);  // Set the validated capacity
                    t.setTrainName(trainName.getText());

                    // Attempt to add the train to the database
                    TrainsDatabase.AddTrain(t, database);
                    JOptionPane.showMessageDialog(frame, "Train added successfully.");
                    frame.dispose();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Capacity must be a valid number.");
                } catch (SQLException e1) {
                    JOptionPane.showMessageDialog(frame, "Operation Failed: " + e1.getMessage());
                }
            }
        });
        panel.add(submit);

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);

    }  
}
