package Trains;
public class Train {
    // train properties.
    private int id;
    private int capacity;
    private String trainName;
// constructor
    public Train(){}
//getter and setters.
    public int getID(){
        return id;
    }
    public void setID(int id){
        this.id = id;
    }
    public int getCapacity(){
        return capacity;
    }
    public void setCapacity(int capacity){
        this.capacity = capacity;
    }
    public String getTrainName(){
        return trainName;
    }
    public void setTrainName(String trainName){
        this.trainName = trainName;
    }
}
