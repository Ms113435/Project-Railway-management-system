package Trains;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import RailwayManagementSystem.Database;
import RailwayManagementSystem.GUI;
import RailwayManagementSystem.Main;
import Trips.TripsDatabase;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.BorderLayout;
import java.awt.Color;

public class EditTrain {

    public EditTrain(JFrame parent, Database database) throws SQLException {

        JFrame frame = new JFrame("Edit Train");
        frame.setSize(750, 400);
        frame.getContentPane().setLayout(new BorderLayout());
        frame.setLocationRelativeTo(parent);
        frame.getContentPane().setBackground(Color.decode("#ebffd8"));

        JPanel panel = new JPanel(new GridLayout(4, 2, 20, 20));
        panel.setBackground(null);
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 30, 50));

        panel.add(GUI.JLabel("ID:"));
        JComboBox<String> id = GUI.JComboBox(TrainsDatabase.getTrainsIDs(database));
        panel.add(id);

        panel.add(GUI.JLabel("Capacity:"));
        JTextField capacity = GUI.JTextField();
        panel.add(capacity);

        panel.add(GUI.JLabel("Train Name:"));
        JTextField trainName = GUI.JTextField();
        panel.add(trainName);

        JButton submit = GUI.JButton("Submit");
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Validate Capacity
                    int trainCapacity = Integer.parseInt(capacity.getText());

                    // Check if capacity is a positive integer
                    if (trainCapacity <= 0) {
                        JOptionPane.showMessageDialog(frame, "Capacity must be a positive number.");
                        return;
                    }

                    // Fetch the selected train and update its details
                    Train t = TrainsDatabase.getTrain(id.getSelectedItem().toString(), database);
                    t.setCapacity(trainCapacity);
                    t.setTrainName(trainName.getText());

                    // Update the train in the database
                    TrainsDatabase.EditTrain(t, database);
                    JOptionPane.showMessageDialog(frame, "Train updated successfully");
                    Main.refreshTable(TripsDatabase.getAllTrips(database));
                    frame.dispose();
                } catch (NumberFormatException ex) {
                    // Handle non-numeric input
                    JOptionPane.showMessageDialog(frame, "Capacity must be a valid number.");
                } catch (SQLException e1) {
                    // Handle SQL errors
                    JOptionPane.showMessageDialog(frame, "Operation Failed: " + e1.getMessage());
                    frame.dispose();
                }
            }
        });
        panel.add(submit);

        JButton delete = GUI.JButton("Delete");
        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Delete the selected train from the database
                    TrainsDatabase.DeleteTrain(id.getSelectedItem().toString(), database);
                    JOptionPane.showMessageDialog(frame, "Train deleted successfully");
                    frame.dispose();
                } catch (SQLException e1) {
                    // Handle SQL errors during deletion
                    JOptionPane.showMessageDialog(frame, "Operation Failed: " + e1.getMessage());
                    frame.dispose();
                }
            }
        });
        panel.add(delete);

        // When a new train ID is selected, load its existing details
        id.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Train t = TrainsDatabase.getTrain(id.getSelectedItem().toString(), database);
                    capacity.setText(String.valueOf(t.getCapacity()));
                    trainName.setText(t.getTrainName());
                } catch (SQLException e1) {
                    JOptionPane.showMessageDialog(frame, "Error: " + e1.getMessage());
                    frame.dispose();
                }
            }
        });

        // Initial population of train details if the selected item is not null
        if (id.getSelectedItem() != null) {
            try {
                Train t = TrainsDatabase.getTrain(id.getSelectedItem().toString(), database);
                capacity.setText(String.valueOf(t.getCapacity()));
                trainName.setText(t.getTrainName());
            } catch (SQLException e1) {
                JOptionPane.showMessageDialog(frame, "Error: " + e1.getMessage());
                frame.dispose();
            }
        }

        frame.getContentPane().add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
